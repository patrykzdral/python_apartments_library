# setup.py
from distutils.core import setup

setup(name='python_apartments_library',
	version='1.0',
	author='Your Name',
	author_email='220878@student.pwr.edu.pl',
	url='https://git.e-science.pl/pzdral220878/python_apartments_library',
	packages=['exception', 'lib'],
 )
